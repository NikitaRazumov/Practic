package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Controller
public class ConverterController {

    public class CurrencyInfo {
        private String name;
        private double rate;
        private int nominal;

        public CurrencyInfo(String name, double rate, int nominal) {
            this.name = name;
            this.rate = rate;
            this.nominal = nominal;
        }

        public String getName() {
            return name;
        }

        public double getRate() {
            return rate;
        }

        public int getNominal() {
            return nominal;
        }
    }

    public class CurrencyData {
        private Map<String, CurrencyInfo> data = new HashMap<>();

        public CurrencyData() {
            data.put("usd", new CurrencyInfo("Доллары", 1.0, 1));
            data.put("rub", new CurrencyInfo("Рубли", 82.725, 1));
            data.put("eur", new CurrencyInfo("Евро", 0.93, 1));
            data.put("byr", new CurrencyInfo("Белорусские рубли", 2.5, 1));
        }

        public CurrencyInfo getCurrencyInfo(String code) {
            return data.get(code);
        }

        public Set<String> getCurrencyCodes() {
            return data.keySet();
        }
    }

    private final CurrencyData currencyData = new CurrencyData();

    @GetMapping("/Converter")
    public String getConverter(Model model, @RequestParam(value = "ConTitle", required = false, defaultValue = "Конвертер") String title) {
        model.addAttribute("ConTitle", title);
        return "Converter";
    }

    @PostMapping("/Converter")
    public String postConverter(Model model, @RequestParam(value = "ConTitle", required = false, defaultValue = "Конвертер") String title,
                                @RequestParam(value = "currencySelect") String selectedCurrency,
                                @RequestParam(value = "amount") double amount) {
        List<String> results = new ArrayList<>();

        CurrencyInfo selectedCurrencyInfo = currencyData.getCurrencyInfo(selectedCurrency);

        for (String currencyCode : currencyData.getCurrencyCodes()) {
            if (!currencyCode.equals(selectedCurrency)) {
                CurrencyInfo currencyInfo = currencyData.getCurrencyInfo(currencyCode);
                double convertedAmount = (amount * currencyInfo.getRate() * selectedCurrencyInfo.getNominal()) / (selectedCurrencyInfo.getRate() * currencyInfo.getNominal());
                results.add(currencyInfo.getName() + ": " + String.format("%.2f", convertedAmount) + " " + currencyCode.toUpperCase());
            }
        }

        model.addAttribute("ConTitle", title);
        model.addAttribute("selectedCurrency", selectedCurrency);
        model.addAttribute("amount", amount);
        model.addAttribute("results", results);

        return "Converter";
    }
}
