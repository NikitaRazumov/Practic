package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {

    @GetMapping("/")
    String getHome(Model model, @RequestParam(value = "Title", required = false, defaultValue = "Выберете инструмент") String title){
        model.addAttribute("Title",title);
        return "Home";
    }

    @GetMapping("/Calculator")
    String getCalculator(Model model, @RequestParam(value = "CalcTitle", required = false, defaultValue = "Калькулятор") String title){
        model.addAttribute("CalcTitle",title);
        return "Calculator";
    }


    @GetMapping("/Home")
    String getHomeC(Model model, @RequestParam(value = "Title", required = false, defaultValue = "Выберете инструмент") String title){
        model.addAttribute("Title",title);
        return "Home";
    }
}